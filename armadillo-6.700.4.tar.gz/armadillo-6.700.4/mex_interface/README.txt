
IMPORTANT!
----------

All mex objects need to be linked _statically_ with BLAS and LAPACK
(or high-performance versions such as OpenBLAS)
in order to work correctly with Matlab.

